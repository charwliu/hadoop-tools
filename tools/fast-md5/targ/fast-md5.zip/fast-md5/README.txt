This is a fast implementation of the MD5 algorithm written in Java.
For details, see the project website at:

    http://www.twmacinta.com/myjava/fast_md5.php
